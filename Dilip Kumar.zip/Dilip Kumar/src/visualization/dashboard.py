import os
import matplotlib.pyplot as plt

# --------------------------------------------------------
# 1. Set project root and folders
# --------------------------------------------------------
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../"))
plots_dir = os.path.join(project_root, "src", "visualization", "plots")
os.makedirs(plots_dir, exist_ok=True)

dashboard_dir = os.path.join(project_root, "Visualizations")
os.makedirs(dashboard_dir, exist_ok=True)
dashboard_file = os.path.join(dashboard_dir, "dashboard.html")

# --------------------------------------------------------
# 2. Automatically detect ALL plots created by plot_generator.py
# --------------------------------------------------------
available_plots = sorted([
    f for f in os.listdir(plots_dir)
    if f.lower().endswith(".png")
])

if not available_plots:
    print("⚠️ No plot images found in:", plots_dir)
    exit()

print("Detected plot files:")
for p in available_plots:
    print(" -", p)

# --------------------------------------------------------
# 3. Create dashboard HTML file
# --------------------------------------------------------
html = """
<html>
<head>
    <title>LinkedIn Analysis Dashboard</title>
    <style>
        body { font-family: Arial; background: #fafafa; padding: 20px; }
        h1 { text-align: center; }
        img { border: 1px solid #ddd; padding: 10px; background: white;
              margin-bottom: 30px; }
        .plot-title { font-size: 20px; font-weight: bold; margin-top: 40px; }
    </style>
</head>
<body>
<h1>📊 LinkedIn Analysis – Visualization Dashboard</h1>
"""

for plot in available_plots:
    display_name = (
        plot.replace("_", " ")
            .replace(".png", "")
            .replace("01 ", "")
            .replace("02 ", "")
            .replace("03 ", "")
            .replace("04 ", "")
            .replace("05 ", "")
            .replace("06 ", "")
            .replace("07 ", "")
            .replace("08 ", "")
            .replace("09 ", "")
            .replace("10 ", "")
            .title()
    )
    
    html += f"<div class='plot-title'>{display_name}</div>"
    html += f"<img src='plots/{plot}' width='900'>"

html += "</body></html>"

with open(dashboard_file, "w", encoding="utf-8") as f:
    f.write(html)

print(f"\n✅ Dashboard HTML created successfully at:\n{dashboard_file}")

# --------------------------------------------------------
# 4. Create dashboard summary grid (combined image)
# --------------------------------------------------------
n_plots = len(available_plots)
cols = 2
rows = (n_plots + 1) // cols

fig, axes = plt.subplots(rows, cols, figsize=(18, rows * 7))
axes = axes.flatten()

for ax, plot_name in zip(axes, available_plots):
    img_path = os.path.join(plots_dir, plot_name)
    try:
        img = plt.imread(img_path)
        ax.imshow(img)
        ax.axis("off")
        ax.set_title(plot_name.replace('.png', '').replace('_', ' ').title(), fontsize=12)
    except Exception as e:
        ax.text(0.5, 0.5, f"Failed to load\n{plot_name}", ha='center')
        ax.axis("off")

# Hide extra empty axes
for ax in axes[len(available_plots):]:
    ax.axis("off")

summary_plot_path = os.path.join(plots_dir, "dashboard_summary_plot.png")
plt.tight_layout()
plt.savefig(summary_plot_path, dpi=150)
plt.close()

print(f"✅ Dashboard summary plot created at:\n{summary_plot_path}")