import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
from pathlib import Path
import warnings
warnings.filterwarnings('ignore')

# ============================================================
# Configuration
# ============================================================
BASE_DIR = Path(r"C:\Users\basil\OneDrive\Desktop\Dilip Kumar")
INPUT_CSV = BASE_DIR / "data" / "result" / "combined_posts_comments_long.csv"
OUTPUT_DIR = BASE_DIR / "src" / "visualization" / "plots"

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

sns.set_style("whitegrid")
plt.rcParams["figure.figsize"] = (12, 8)
plt.rcParams["font.size"] = 10


# ============================================================
# Helper: save plot
# ============================================================
def save_plot(name):
    """Save the plot using a consistent naming format."""
    filepath = OUTPUT_DIR / f"{name}.png"
    plt.savefig(filepath, dpi=300, bbox_inches="tight")
    plt.close()


# ============================================================
# Load Data
# ============================================================
def load_data():
    print("=" * 60)
    print("Loading Data")
    print("=" * 60)

    if not INPUT_CSV.exists():
        print(f"❌ Error: File not found: {INPUT_CSV}")
        return None

    df = pd.read_csv(INPUT_CSV, encoding="utf-8")

    print(f"Loaded {len(df)} rows")
    print(f"Unique posts: {df['post_urn_id'].nunique()}")
    print(f"Posts with comments: {df['has_comment'].sum()}")
    print(df.columns.tolist())

    return df


# ============================================================
# Plot 1: Sentiment Distribution
# ============================================================
def plot_1_sentiment_distribution(df):
    fig, axes = plt.subplots(1, 2, figsize=(14, 6))

    colors = {"Positive": "#2ecc71", "Neutral": "#95a5a6", "Negative": "#e74c3c"}

    # Posts
    post_sentiment = df.drop_duplicates("post_urn_id")["post_sentiment_label"].value_counts()
    axes[0].bar(post_sentiment.index,
                post_sentiment.values,
                color=[colors.get(x, "#3498db") for x in post_sentiment.index],
                alpha=0.8)
    axes[0].set_title("Post Sentiment Distribution", fontsize=14, fontweight="bold")

    # Comments
    comment_df = df[df["has_comment"]]
    if len(comment_df) > 0:
        comment_sentiment = comment_df["comment_sentiment_label"].value_counts()
        axes[1].bar(
            comment_sentiment.index,
            comment_sentiment.values,
            color=[colors.get(x, "#3498db") for x in comment_sentiment.index],
            alpha=0.8,
        )
        axes[1].set_title("Comment Sentiment Distribution", fontsize=14, fontweight="bold")

    plt.tight_layout()
    save_plot("01_sentiment_distribution")
    print("✓ Saved: 01_sentiment_distribution.png")


# ============================================================
# Plot 2: Sentiment Score Distribution
# ============================================================
def plot_2_sentiment_scores_distribution(df):
    fig, axes = plt.subplots(2, 1, figsize=(12, 10))

    # Posts
    post_data = df.drop_duplicates("post_urn_id")
    axes[0].hist(post_data["post_sentiment_compound"], bins=30,
                 color="#3498db", alpha=0.7, edgecolor="black")
    axes[0].set_title("Post Sentiment Score Distribution")

    # Comments
    comment_data = df[df["has_comment"]]
    if len(comment_data) > 0:
        axes[1].hist(comment_data["comment_sentiment_compound"], bins=30,
                     color="#e67e22", alpha=0.7, edgecolor="black")
        axes[1].set_title("Comment Sentiment Score Distribution")

    plt.tight_layout()
    save_plot("02_sentiment_scores_distribution")
    print("✓ Saved: 02_sentiment_scores_distribution.png")


# ============================================================
# Plot 3: Post vs Comment Sentiment Heatmap
# ============================================================
def plot_3_post_vs_comment_sentiment(df):
    comment_df = df[df["has_comment"]]

    if len(comment_df) == 0:
        print("⚠ Skipping post vs comment heatmap (no comments)")
        return

    crosstab = pd.crosstab(comment_df["post_sentiment_label"],
                           comment_df["comment_sentiment_label"])

    plt.figure(figsize=(10, 8))
    sns.heatmap(crosstab, annot=True, fmt="d", cmap="YlOrRd")
    plt.title("Post Sentiment vs Comment Sentiment")
    plt.tight_layout()

    save_plot("03_post_vs_comment_sentiment")
    print("✓ Saved: 03_post_vs_comment_sentiment.png")


# ============================================================
# Plot 4: Sentiment Match
# ============================================================
def plot_4_sentiment_match(df):
    print("\n------------------------------------------------------------")
    print("Plot 4: Sentiment Match Between Post & Comments")
    print("------------------------------------------------------------")

    if "post_sentiment_label" not in df.columns or "comment_sentiment_label" not in df.columns:
        print("⚠ Missing sentiment columns")
        return

    df["sentiment_match"] = (df["post_sentiment_label"] == df["comment_sentiment_label"])

    match_counts = df["sentiment_match"].value_counts()

    plt.figure(figsize=(7, 6))
    sns.barplot(x=match_counts.index.astype(str), y=match_counts.values)
    plt.title("Do Comments Match Post Sentiment?")
    plt.xlabel("Match")
    plt.ylabel("Count")

    save_plot("04_sentiment_match")
    print("✓ Saved: 04_sentiment_match.png")


# ============================================================
# Plot 5: Engagement vs Sentiment
# ============================================================
def plot_5_engagement_metrics(df):
    print("\n------------------------------------------------------------")
    print("Plot 5: Engagement Metrics vs Post Sentiment")
    print("------------------------------------------------------------")

    posts = df.drop_duplicates("post_full_urn")

    if "post_stats.total_reactions" not in posts.columns:
        print("⚠ Missing reaction column — skipping")
        return

    avg_reactions = posts.groupby("post_sentiment_label")["post_stats.total_reactions"].mean()

    plt.figure(figsize=(10, 6))
    avg_reactions.plot(kind="bar")
    plt.title("Average Total Reactions by Sentiment")
    plt.xlabel("Sentiment")
    plt.ylabel("Average Reactions")
    plt.tight_layout()

    save_plot("05_engagement_metrics")
    print("✓ Saved: 05_engagement_metrics.png")


# ============================================================
# Plot 6: Reaction Types Distribution
# ============================================================
def plot_6_reaction_types(df):
    print("\n------------------------------------------------------------")
    print("Plot 6: Reaction Types Distribution")
    print("------------------------------------------------------------")

    reaction_cols = [
        "post_stats.like", "post_stats.love", "post_stats.support",
        "post_stats.celebrate", "post_stats.funny", "post_stats.insight",
        "post_stats.reposts"
    ]

    existing = [col for col in reaction_cols if col in df.columns]
    if not existing:
        print("⚠ No reaction columns found")
        return

    sums = df[existing].sum()

    plt.figure(figsize=(10, 6))
    sns.barplot(x=sums.index, y=sums.values)
    plt.xticks(rotation=45)
    plt.title("Reaction Types Distribution")
    plt.tight_layout()

    save_plot("06_reaction_types")
    print("✓ Saved: 06_reaction_types.png")


# ============================================================
# Plot 7: Posts Over Time
# ============================================================
def plot_7_posts_over_time(df):
    posts = df.drop_duplicates("post_urn_id")

    if "post_posted_at.date" not in posts.columns:
        print("⚠ No date column, skipping time-series plot")
        return

    posts["date"] = pd.to_datetime(posts["post_posted_at.date"], errors="coerce")
    posts = posts.dropna(subset=["date"])

    plt.figure(figsize=(14, 6))
    posts_per_day = posts.groupby(posts["date"].dt.date).size()

    plt.plot(posts_per_day.index, posts_per_day.values, marker="o")
    plt.xticks(rotation=45)
    plt.title("Posts Over Time")
    plt.tight_layout()

    save_plot("07_posts_over_time")
    print("✓ Saved: 07_posts_over_time.png")


# ============================================================
# Plot 8: Top Authors
# ============================================================
def plot_8_top_authors(df):
    print("\n------------------------------------------------------------")
    print("Plot 8: Top Authors")
    print("------------------------------------------------------------")

    if "post_author.full_name" not in df.columns:
        print("⚠ No author column")
        return

    top = df["post_author.full_name"].value_counts().head(15)

    plt.figure(figsize=(8, 10))
    sns.barplot(y=top.index, x=top.values)
    plt.title("Top Authors by Post Count")
    plt.tight_layout()

    save_plot("08_top_authors")
    print("✓ Saved: 08_top_authors.png")


# ============================================================
# Plot 9: Text Length Analysis
# ============================================================
def plot_9_word_length_analysis(df):
    posts = df.drop_duplicates("post_urn_id")
    posts["text_length"] = posts["post_text"].astype(str).str.len()

    plt.figure(figsize=(12, 6))
    sns.boxplot(x=posts["post_sentiment_label"], y=posts["text_length"],
                order=["Negative", "Neutral", "Positive"])
    plt.title("Text Length vs Sentiment")
    plt.tight_layout()

    save_plot("09_text_length_analysis")
    print("✓ Saved: 09_text_length_analysis.png")


# ============================================================
# Plot 10: Correlation Matrix
# ============================================================
def plot_10_correlation_matrix(df):
    posts = df.drop_duplicates("post_urn_id")

    numerical = [
        "post_sentiment_compound",
        "post_sentiment_positive",
        "post_sentiment_negative",
        "post_sentiment_neutral",
        "post_stats.total_reactions",
        "post_stats.comments",
        "post_stats.reposts"
    ]

    existing = [c for c in numerical if c in posts.columns]

    if len(existing) < 2:
        print("⚠ Not enough columns for correlation")
        return

    corr = posts[existing].corr()

    plt.figure(figsize=(12, 10))
    sns.heatmap(corr, annot=True, cmap="coolwarm")
    plt.title("Correlation Matrix")
    plt.tight_layout()

    save_plot("10_correlation_matrix")
    print("✓ Saved: 10_correlation_matrix.png")


# ============================================================
# Main
# ============================================================
def main():
    print("=" * 60)
    print("Creating Sentiment Analysis Visualizations")
    print("=" * 60)

    df = load_data()
    if df is None:
        return

    print("\n" + "=" * 60)
    print("Generating Plots")
    print("=" * 60)

    plot_1_sentiment_distribution(df)
    plot_2_sentiment_scores_distribution(df)
    plot_3_post_vs_comment_sentiment(df)
    plot_4_sentiment_match(df)
    plot_5_engagement_metrics(df)
    plot_6_reaction_types(df)
    plot_7_posts_over_time(df)
    plot_8_top_authors(df)
    plot_9_word_length_analysis(df)
    plot_10_correlation_matrix(df)

    print("\nAll plots saved to:", OUTPUT_DIR)
    print("✓ Visualization complete!")


if __name__ == "__main__":
    main()