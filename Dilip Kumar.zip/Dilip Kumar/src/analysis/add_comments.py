import json
import pandas as pd
from pathlib import Path

# -------------------------------
# Paths
# -------------------------------
BASE_DIR = Path(__file__).resolve().parent.parent.parent

posts_json_path = BASE_DIR / "data" / "processed" / "filtered_posts.json"
comments_folder = BASE_DIR / "data" / "processed" / "comments"

output_json = BASE_DIR / "data" / "processed" / "filtered_posts_with_comments.json"

# -------------------------------
# Step 1: Load posts JSON
# -------------------------------
with open(posts_json_path, "r", encoding="utf-8") as f:
    posts = json.load(f)

print(f"Loaded {len(posts)} posts")

# -------------------------------
# Step 2: Attach comments
# -------------------------------
for post in posts:
    post_id = post.get("post_id")

    comments_file = comments_folder / f"linkedin-{post_id}.csv"

    if comments_file.exists():
        df_comments = pd.read_csv(comments_file)

        if "Comment" in df_comments.columns:
            post["comments"] = (
                df_comments["Comment"]
                .dropna()
                .astype(str)
                .tolist()
            )
        else:
            post["comments"] = []
    else:
        post["comments"] = []

# -------------------------------
# Step 3: Save updated JSON
# -------------------------------
with open(output_json, "w", encoding="utf-8") as f:
    json.dump(posts, f, indent=2, ensure_ascii=False)

print(f"✅ Saved posts with comments → {output_json}")
