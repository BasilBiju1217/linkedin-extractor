import json
import pandas as pd

# -------- PATHS --------
JSON_FILE = "dataset_linkedin-profile-posts_2025-12-05_14-00-17-580.json"
CSV_FILE = "output.csv"

# -------- LOAD JSON --------
with open(JSON_FILE, "r", encoding="utf-8") as f:
    data = json.load(f)

# -------- CONVERT TO CSV --------
df = pd.DataFrame(data)
df.to_csv(CSV_FILE, index=False, encoding="utf-8-sig")

print(f"✅ Converted JSON to CSV: {CSV_FILE}")
