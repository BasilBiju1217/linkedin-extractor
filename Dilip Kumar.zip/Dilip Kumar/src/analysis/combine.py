import pandas as pd
import json
import re
from pathlib import Path

# -----------------------------
# Paths
# -----------------------------
BASE_DIR = Path(r"C:\Users\basil\OneDrive\Desktop\Dilip Kumar")
POSTS_CSV = BASE_DIR / "data" / "result" / "results_filtered_posts_cleaned.csv"
COMMENTS_FOLDER = BASE_DIR / "data" / "result" / "comments"
OUTPUT_CSV_PATH = BASE_DIR / "data" / "result" / "combined_posts_comments_long.csv"
OUTPUT_JSON_PATH = BASE_DIR / "data" / "result" / "combined_posts_comments_nested.json"

# -----------------------------
# Helper functions
# -----------------------------
def extract_urn_id(urn_string):
    """Extract numeric ID from URN string."""
    if pd.isna(urn_string):
        return None
    match = re.search(r'(\d+)$', str(urn_string))
    if match:
        return match.group(1)
    return None

def load_posts_data():
    """Load filtered posts CSV."""
    try:
        df = pd.read_csv(POSTS_CSV)
        print(f"Loaded posts: {len(df)} rows from {POSTS_CSV.name}")
        df['post_urn_id'] = df['full_urn'].apply(extract_urn_id)
        return df
    except Exception as e:
        print(f"Error loading posts CSV: {e}")
        return None

def load_comments_data():
    """Load all comments CSVs."""
    comment_files = list(COMMENTS_FOLDER.glob("*.csv"))
    all_comments = []
    for f in comment_files:
        try:
            df = pd.read_csv(f)
            urn_id = re.search(r'linkedin-(\d+)', f.name)
            if urn_id:
                df['post_urn_id'] = urn_id.group(1)
                all_comments.append(df)
        except Exception as e:
            print(f"Error loading {f.name}: {e}")
    if all_comments:
        combined = pd.concat(all_comments, ignore_index=True)
        print(f"Loaded total comments: {len(combined)}")
        return combined
    return pd.DataFrame(columns=[
        "Full Name","Profile URL","Headline","Comment","Timestamp",
        "Comment URN","post_urn_id","processed_comment",
        "sentiment_negative","sentiment_neutral","sentiment_positive",
        "sentiment_compound","sentiment_label"
    ])

def create_long_format_csv(posts_df, comments_df):
    """Create long-format CSV: one row per comment."""
    posts_subset = posts_df.copy()
    posts_subset.columns = ['post_' + c if c != 'post_urn_id' else c for c in posts_subset.columns]

    if comments_df.empty:
        posts_subset['has_comment'] = False
        return posts_subset

    comments_subset = comments_df.copy()
    comments_subset.columns = ['comment_' + c if c != 'post_urn_id' else c for c in comments_subset.columns]

    combined = pd.merge(posts_subset, comments_subset, on='post_urn_id', how='left')
    combined['has_comment'] = combined['comment_Comment'].notna() if 'comment_Comment' in combined.columns else False
    return combined

def create_nested_json(posts_df, comments_df):
    """Create nested JSON: one object per post with comments nested."""
    nested_data = []
    comments_grouped = {}
    if not comments_df.empty:
        for post_urn in comments_df['post_urn_id'].unique():
            post_comments = comments_df[comments_df['post_urn_id'] == post_urn]
            comments_list = []
            for _, row in post_comments.iterrows():
                comment_dict = row.to_dict()
                comment_dict.pop('post_urn_id', None)
                comments_list.append(comment_dict)
            comments_grouped[post_urn] = comments_list

    for _, post_row in posts_df.iterrows():
        post_urn_id = post_row['post_urn_id']
        post_comments = comments_grouped.get(post_urn_id, [])
        comment_stats = {
            'total_comments': len(post_comments),
            'positive_comments': sum(1 for c in post_comments if c.get('sentiment_label') == 'Positive'),
            'negative_comments': sum(1 for c in post_comments if c.get('sentiment_label') == 'Negative'),
            'neutral_comments': sum(1 for c in post_comments if c.get('sentiment_label') == 'Neutral'),
            'avg_sentiment_compound': (sum(c.get('sentiment_compound',0) for c in post_comments)/len(post_comments)
                                       if post_comments else 0)
        }
        record = post_row.to_dict()
        record['comment_stats'] = comment_stats
        record['comments'] = post_comments
        nested_data.append(record)
    return nested_data

# -----------------------------
# Main
# -----------------------------
def main():
    posts_df = load_posts_data()
    if posts_df is None or len(posts_df) == 0:
        print("No posts data found.")
        return

    comments_df = load_comments_data()

    # Long-format CSV
    csv_df = create_long_format_csv(posts_df, comments_df)
    csv_df.to_csv(OUTPUT_CSV_PATH, index=False, encoding='utf-8')
    print(f"Long-format CSV saved → {OUTPUT_CSV_PATH} ({len(csv_df)} rows)")

    # Nested JSON
    nested_json = create_nested_json(posts_df, comments_df)
    with open(OUTPUT_JSON_PATH, 'w', encoding='utf-8') as f:
        json.dump(nested_json, f, indent=2, ensure_ascii=False)
    print(f"Nested JSON saved → {OUTPUT_JSON_PATH} ({len(nested_json)} records)")

if __name__ == "__main__":
    main()