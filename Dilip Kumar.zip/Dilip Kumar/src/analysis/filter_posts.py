import pandas as pd
from pathlib import Path
import re
import json
import ast

# -------------------------------
# Paths
# -------------------------------
BASE_DIR = Path(__file__).resolve().parent.parent.parent

comments_folder = BASE_DIR / "data" / "processed" / "comments"
posts_csv = BASE_DIR / "data" / "raw" / "dataset_linkedin-profile-posts_2025-12-05_14-00-17-580.csv"

output_json = BASE_DIR / "data" / "processed" / "filtered_posts.json"
output_json.parent.mkdir(parents=True, exist_ok=True)

# -------------------------------
# Step 1: Get post URNs from comment CSV filenames
# -------------------------------
post_urns = set()

for f in comments_folder.glob("*.csv"):
    match = re.search(r'linkedin-(\d+)', f.stem)
    if match:
        post_urns.add(match.group(1))

print(f"Found {len(post_urns)} posts with comments.")

# -------------------------------
# Step 2: Read posts CSV
# -------------------------------
df = pd.read_csv(posts_csv)
print(f"Total posts in main CSV: {len(df)}")

# -------------------------------
# Step 3: Extract post_id
# -------------------------------
def extract_post_id(row):
    for col in ["urn.activity_urn", "urn.ugcPost_urn", "full_urn"]:
        if col in row and pd.notna(row[col]):
            m = re.search(r'(\d+)', str(row[col]))
            if m:
                return m.group(1)
    return None

df["post_id"] = df.apply(extract_post_id, axis=1)

df = df[df["post_id"].isin(post_urns)].copy()
print(f"Filtered posts count: {len(df)}")

# -------------------------------
# Step 4: Parse stringified dict columns
# -------------------------------
DICT_COLUMNS = ["urn", "posted_at", "author", "stats", "media", "document", "article"]

def parse_dict(val):
    if isinstance(val, str) and val.startswith("{"):
        try:
            return ast.literal_eval(val)
        except Exception:
            return None
    return val

for col in DICT_COLUMNS:
    if col in df.columns:
        df[col] = df[col].apply(parse_dict)

# -------------------------------
# Step 5: Flatten nested dictionaries
# -------------------------------
def flatten_record(row):
    flat = {}

    for key, value in row.items():
        if isinstance(value, dict):
            for sub_k, sub_v in value.items():
                flat[f"{key}.{sub_k}"] = sub_v
        else:
            flat[key] = value

    return flat

posts_list = [flatten_record(row) for row in df.to_dict(orient="records")]

# -------------------------------
# Step 6: Save JSON
# -------------------------------
with open(output_json, "w", encoding="utf-8") as f:
    json.dump(posts_list, f, indent=2, ensure_ascii=False)

print(f"✅ Saved filtered posts JSON → {output_json}")
