import json
import pandas as pd
from pathlib import Path
from urllib.parse import urlparse, urlunparse

# -------------------------
# PATH (update this)
# -------------------------
JSON_FILE = Path(r"c:\Users\basil\OneDrive\Desktop\Dilip Kumar\data\raw\dataset_linkedin-profile-posts_2025-12-05_14-00-17-580.json")
OUTPUT_FILE = Path("post_urls.csv")

def clean_url(url):
    parsed = urlparse(url)
    return urlunparse(parsed._replace(query=""))  # remove tracking params

def extract_and_save_post_urls(json_path, output_path):
    with open(json_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    post_urls = set()

    for post in data:
        url = post.get("url")
        if url:
            post_urls.add(clean_url(url))

    df = pd.DataFrame({"post_url": sorted(post_urls)})
    df.to_csv(output_path, index=False)

    print(f"\n✅ Saved {len(df)} post URLs to: {output_path.resolve()}")

if __name__ == "__main__":
    extract_and_save_post_urls(JSON_FILE, OUTPUT_FILE)
