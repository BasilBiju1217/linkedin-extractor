import json
from pathlib import Path

# -----------------------------
# Paths
# -----------------------------
BASE_DIR = Path(r"C:\Users\basil\OneDrive\Desktop\Dilip Kumar\data\processed")
input_json = BASE_DIR / 'filtered_posts.json'
output_json = BASE_DIR / 'filtered_posts_cleaned.json'

# -----------------------------
# Helpers
# -----------------------------
def clean_value(value):
    if value is None or str(value).strip() == '' or str(value).lower() == 'nan':
        return None
    return value

def restructure_to_nested(post):
    """Convert flat dict post to nested JSON structure"""
    cleaned_post = {}

    # Basic fields
    for field in ['full_urn', 'text', 'url', 'post_type']:
        val = clean_value(post.get(field))
        if val:
            cleaned_post[field] = val

    # posted_at object
    posted_at = {}
    if 'posted_at' in post and isinstance(post['posted_at'], dict):
        date = clean_value(post['posted_at'].get('date'))
        timestamp = clean_value(post['posted_at'].get('timestamp'))
        if date:
            posted_at['date'] = date
        if timestamp:
            posted_at['timestamp'] = int(timestamp)
    if posted_at:
        cleaned_post['posted_at'] = posted_at

    # Author object
    author = {}
    if 'author' in post and isinstance(post['author'], dict):
        for key in ['full_name', 'headline', 'username', 'profile_url']:
            val = clean_value(post['author'].get(key))
            if val:
                author[key] = val
    if author:
        cleaned_post['author'] = author

    # Stats object
    stats = {}
    if 'stats' in post and isinstance(post['stats'], dict):
        for key in ['total_reactions', 'like', 'support', 'love', 'insight',
                    'celebrate', 'funny', 'comments', 'reposts']:
            val = clean_value(post['stats'].get(key))
            if val is not None:
                stats[key] = int(val)
    if stats:
        cleaned_post['stats'] = stats

    return cleaned_post

# -----------------------------
# Load filtered_posts.json
# -----------------------------
with open(input_json, 'r', encoding='utf-8') as f:
    data = json.load(f)

print(f"Loaded {len(data)} posts from {input_json.name}")

# -----------------------------
# Clean posts
# -----------------------------
cleaned_posts = [restructure_to_nested(post) for post in data]

# Save cleaned JSON
with open(output_json, 'w', encoding='utf-8') as f:
    json.dump(cleaned_posts, f, indent=2, ensure_ascii=False)

print(f"✅ Saved cleaned JSON → {output_json}")
print(f"Total cleaned posts: {len(cleaned_posts)}")