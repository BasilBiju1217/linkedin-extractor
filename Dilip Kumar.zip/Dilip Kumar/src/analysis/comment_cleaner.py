import pandas as pd
from pathlib import Path
import re

# -------------------------
# BASE PATHS
# -------------------------
BASE_DIR = Path(__file__).resolve().parents[2]
INPUT_FOLDER = BASE_DIR / "data" / "raw" / "comments"
OUTPUT_FOLDER = INPUT_FOLDER / "formatted"

OUTPUT_FOLDER.mkdir(parents=True, exist_ok=True)

# -------------------------
# COLUMNS TO DROP
# -------------------------
COLS_TO_DROP = [
    "First Name",
    "Last Name",
    "Type",
    "Is Edited",
    "Replies Count",
    "Is Post Author",
    "Has Reply From Post Author"
]

# -------------------------
# PROCESS FILES
# -------------------------
for csv_file in INPUT_FOLDER.glob("*.csv"):
    print(f"Processing: {csv_file.name}")

    try:
        # Read CSV safely
        df = pd.read_csv(csv_file, encoding="utf-8", low_memory=False)

        if df.empty:
            print("  ⚠️ Empty CSV — skipped\n")
            continue

        # Drop unwanted columns
        df.drop(columns=[c for c in COLS_TO_DROP if c in df.columns], inplace=True)

        # -------------------------
        # EXTRACT ACTIVITY / UGCP POST ID
        # -------------------------
        extracted_number = None

        if "Comment URN" in df.columns:
            for urn in df["Comment URN"].dropna():
                match = re.search(r"(activity|ugcPost):(\d+)", str(urn))
                if match:
                    extracted_number = match.group(2)
                    break

        # Fallback to filename if URN not found
        if not extracted_number:
            print("  ⚠️ URN not found — using filename")
            extracted_number = csv_file.stem

        # -------------------------
        # UNIQUE OUTPUT FILENAME
        # -------------------------
        base_name = f"linkedin-{extracted_number}"
        output_path = OUTPUT_FOLDER / f"{base_name}.csv"
        counter = 1

        while output_path.exists():
            output_path = OUTPUT_FOLDER / f"{base_name}_{counter}.csv"
            counter += 1

        # Save cleaned CSV
        df.to_csv(output_path, index=False, encoding="utf-8")
        print(f"  ✅ Saved → {output_path.name}\n")

    except Exception as e:
        print(f"  ❌ Error processing {csv_file.name}: {e}\n")

print("🎯 Automation completed successfully.")
