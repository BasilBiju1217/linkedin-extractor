import json
import pandas as pd
from pathlib import Path

# -----------------------------
# File paths
# -----------------------------
BASE_DIR = Path(r"C:\Users\basil\OneDrive\Desktop\Dilip Kumar\data\processed")
input_json = BASE_DIR / "filtered_posts.json"
output_csv = BASE_DIR / "filtered_posts.csv"

# -----------------------------
# Columns to keep in final CSV
# -----------------------------
final_columns = [
    'author.headline', 'author.profile_url', 'author.username', 'full_urn',
    'post_type', 'posted_at.date','posted_at.timestamp','comment',
    'stats.celebrate', 'stats.comments', 'stats.funny', 'stats.insight',
    'stats.like', 'stats.love', 'stats.reposts', 'stats.support', 'stats.total_reactions',
    'text','url', 'author.full_name'
]

# -----------------------------
# Load JSON
# -----------------------------
with open(input_json, 'r', encoding='utf-8') as f:
    posts = json.load(f)
print(f"Loaded {len(posts)} posts from {input_json.name}")

# -----------------------------
# Normalize JSON to flat table
# -----------------------------
df = pd.json_normalize(posts)

# Combine first_name and last_name into author.full_name if not already present
if 'author.full_name' not in df.columns:
    first = df.get('author.first_name', pd.Series(['']*len(df)))
    last = df.get('author.last_name', pd.Series(['']*len(df)))
    df['author.full_name'] = (first.fillna('') + ' ' + last.fillna('')).str.strip()
    print("Created 'author.full_name' column")

# Keep only final columns that exist in the DataFrame
cols_present = [c for c in final_columns if c in df.columns]
df = df[cols_present]
print(f"Selected {len(cols_present)} columns for output")

# -----------------------------
# Save CSV
# -----------------------------
df.to_csv(output_csv, index=False)
print(f"✅ CSV saved → {output_csv}")