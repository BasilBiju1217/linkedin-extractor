import pandas as pd
import re
from pathlib import Path
import nltk
from nltk.sentiment import SentimentIntensityAnalyzer

# Make sure NLTK resources are downloaded
nltk.download('vader_lexicon')
nltk.download('punkt')
nltk.download('stopwords')

# ------------------- Configuration -------------------
# Input paths
POSTS_CSV = Path(r"c:\Users\basil\OneDrive\Desktop\Dilip Kumar\data\processed\filtered_posts_cleaned.csv")
COMMENTS_FOLDER = Path(r"C:\Users\basil\OneDrive\Desktop\Dilip Kumar\data\processed\comments")

# Output paths
POSTS_RESULTS_PATH = Path(r"C:\Users\basil\OneDrive\Desktop\Dilip Kumar\data\result")
COMMENTS_RESULTS_PATH = Path(r"C:\Users\basil\OneDrive\Desktop\Dilip Kumar\data\result\comments")

# Create result folders if they don't exist
POSTS_RESULTS_PATH.mkdir(parents=True, exist_ok=True)
COMMENTS_RESULTS_PATH.mkdir(parents=True, exist_ok=True)

# ------------------- Sentiment Analyzer -------------------
class SentimentAnalyzer:
    def __init__(self):
        self.sia = SentimentIntensityAnalyzer()
    
    def clean_text(self, text):
        if pd.isna(text):
            return ""
        text = str(text).lower()
        text = re.sub(r'http\S+|www\S+|https\S+', '', text)
        text = re.sub(r'@\w+', '', text)
        text = re.sub(r'#', '', text)
        text = re.sub(r'[^a-zA-Z\s]', '', text)
        text = ' '.join(text.split())
        return text
    
    def get_sentiment_scores(self, text):
        if not text:
            return {'neg': 0, 'neu': 0, 'pos': 0, 'compound': 0}
        return self.sia.polarity_scores(text)
    
    def classify_sentiment(self, compound):
        if compound >= 0.05:
            return 'Positive'
        elif compound <= -0.05:
            return 'Negative'
        else:
            return 'Neutral'
    
    def analyze_dataframe(self, df, text_column, processed_col_name):
        df = df.copy()
        df[processed_col_name] = df[text_column].apply(self.clean_text)
        scores = df[processed_col_name].apply(self.get_sentiment_scores)
        df['sentiment_negative'] = scores.apply(lambda x: x['neg'])
        df['sentiment_neutral'] = scores.apply(lambda x: x['neu'])
        df['sentiment_positive'] = scores.apply(lambda x: x['pos'])
        df['sentiment_compound'] = scores.apply(lambda x: x['compound'])
        df['sentiment_label'] = df['sentiment_compound'].apply(self.classify_sentiment)
        return df

# ------------------- Processing Functions -------------------
def process_posts(analyzer):
    print("\nProcessing Posts...")
    try:
        df = pd.read_csv(POSTS_CSV)
    except Exception as e:
        print(f"Error reading posts CSV: {e}")
        return None
    
    if 'text' not in df.columns:
        print("Error: 'text' column not found in posts CSV")
        return None
    
    df = analyzer.analyze_dataframe(df, text_column='text', processed_col_name='processed_text')
    output_file = POSTS_RESULTS_PATH / f"results_{POSTS_CSV.stem}.csv"
    df.to_csv(output_file, index=False, encoding='utf-8')
    print(f"Posts sentiment saved to: {output_file}")
    return df

def extract_urn_from_filename(filename):
    match = re.search(r'linkedin-(\d+)', filename)
    if match:
        return match.group(1)
    return None

def process_comments(analyzer):
    print("\nProcessing Comments...")
    comment_files = list(COMMENTS_FOLDER.glob("*.csv"))
    if not comment_files:
        print("No comment CSV files found.")
        return None
    
    all_comments = []
    for file in comment_files:
        try:
            df = pd.read_csv(file)
        except Exception as e:
            print(f"Error reading {file.name}: {e}")
            continue
        
        if 'Comment' not in df.columns:
            print(f"'Comment' column not found in {file.name}")
            continue
        
        urn_id = extract_urn_from_filename(file.name)
        if urn_id:
            df['post_urn_id'] = urn_id
        else:
            print(f"Could not extract URN from {file.name}, skipping.")
            continue
        
        df = analyzer.analyze_dataframe(df, text_column='Comment', processed_col_name='processed_comment')
        
        output_file = COMMENTS_RESULTS_PATH / f"results_{file.stem}.csv"
        df.to_csv(output_file, index=False, encoding='utf-8')
        print(f"Comments sentiment saved to: {output_file}")
        all_comments.append(df)
    
    if all_comments:
        return pd.concat(all_comments, ignore_index=True)
    return None

# ------------------- Main -------------------
def main():
    analyzer = SentimentAnalyzer()
    
    posts_df = process_posts(analyzer)
    comments_df = process_comments(analyzer)
    
    print("\nProcessing Completed!")
    if posts_df is not None:
        print(f"Total posts processed: {len(posts_df)}")
    if comments_df is not None:
        print(f"Total comments processed: {len(comments_df)}")

if __name__ == "__main__":
    main()